<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cookies</title>
</head>
<body>
    <h1>Elija un idioma / Choose a language</h1>
    <form method="post" action="lang.php">
        <label for="lang">Idiomas: </label>
        <select name="lang" id="lang">
            <option value="es">Español</option>
            <option value="en">Inglés</option>
        </select>
        <input type="submit" value="Guardar">
    </form>    


    
</body>
</html>